
#pragma once

class CSEM
{
public:
    CSEM(LONG lMaximumCount, LONG lInitialCount = 0, LPCTSTR lpName = nullptr, LPSECURITY_ATTRIBUTES pSecurity = nullptr)
    {
        m_hsem = ::CreateSemaphore(pSecurity, lInitialCount, lMaximumCount, lpName);
        ASSERT(IsValid());
    }

    ~CSEM()
    {
        if (IsValid())
            VERIFY(::CloseHandle(m_hsem));
    }

    BOOL Open(DWORD dwAccess, BOOL bInheritHandle, LPCTSTR pszName)
    {
        if (IsValid())
            VERIFY(::CloseHandle(m_hsem));
        m_hsem = ::OpenSemaphore(dwAccess, bInheritHandle, pszName);
        return (IsValid());
    }

    void Wait(DWORD dwMilliseconds = INFINITE)
    {
        ::WaitForSingleObject(m_hsem, dwMilliseconds);
    }

    BOOL Release(LONG lReleaseCount = 1, LPLONG lpPreviousCount = nullptr)
    {
        return ::ReleaseSemaphore(m_hsem, lReleaseCount, lpPreviousCount);
    }

    HANDLE& GetHandle()
    {
        return m_hsem;
    }
    operator HANDLE()
    {
        return m_hsem;
    }
    BOOL IsValid()
    {
        return m_hsem != nullptr;
    }

private:
    CSEM(const CSEM& sem);
    CSEM operator = (const CSEM& sem);
private:
    HANDLE m_hsem;
};
