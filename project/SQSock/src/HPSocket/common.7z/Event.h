

#pragma once

class CEvt
{
public:
    CEvt(BOOL bManualReset = FALSE, BOOL bInitialState = FALSE, LPCTSTR pszName = nullptr, LPSECURITY_ATTRIBUTES pSecurity = nullptr)
    {
        m_hEvent = ::CreateEvent(pSecurity, bManualReset, bInitialState, pszName);
        ASSERT(IsValid());
    }

    ~CEvt()
    {
        if (IsValid())
            VERIFY(::CloseHandle(m_hEvent));
    }

    BOOL Open(DWORD dwAccess, BOOL bInheritHandle, LPCTSTR pszName)
    {
        if (IsValid())
            VERIFY(::CloseHandle(m_hEvent));
        m_hEvent = ::OpenEvent(dwAccess, bInheritHandle, pszName);
        return (IsValid());
    }

    BOOL Pulse()
    {
        return (::PulseEvent(m_hEvent));
    }
    BOOL Reset()
    {
        return (::ResetEvent(m_hEvent));
    }
    BOOL Set()
    {
        return (::SetEvent(m_hEvent));
    }

    BOOL IsValid()
    {
        return m_hEvent != nullptr;
    }

    HANDLE GetHandle()
    {
        return m_hEvent;
    }
    const HANDLE GetHandle()  const
    {
        return m_hEvent;
    }

    operator HANDLE()
    {
        return m_hEvent;
    }
    operator const HANDLE()  const
    {
        return m_hEvent;
    }

private:
    CEvt(const CEvt&);
    CEvt operator = (const CEvt&);

private:
    HANDLE m_hEvent;
};

